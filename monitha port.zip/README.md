# Monitha Lokesh K — Portfolio

Deployed at **https://Monitha11.github.io**

## 🚀 Setup
1. Create a GitHub repository named `Monitha11.github.io`
2. Upload these files.
3. Wait a minute, then open `https://Monitha11.github.io/`

## 🧩 Features
- One-page dark gradient design
- Smooth scroll navigation
- Fade-in section animations
- Center “Back to Top” button with glow
- Responsive layout
- Links open in new tabs
